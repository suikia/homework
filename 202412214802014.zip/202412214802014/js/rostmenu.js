"use strict";

// 全局变量
var canvas, gl;
var program;
var transformLoc; // 变换矩阵位置
var bufferId;     // 顶点缓冲区（复用）

// 变换参数
var theta = 0.0;    // 旋转角度
var scale = 1.0;    // 缩放比例
var tx = 0.0, ty = 0.0; // 平移量
var direction = 1;  // 旋转方向
var delay = 100;    // 动画延迟(ms)
var currentShape = "diamond"; // 当前图形

// 图形顶点数据集合
const shapes = {
    // 菱形（4顶点）
    diamond: new Float32Array([
         0.0,  0.5,  0.0,
        -0.5,  0.0,  0.0,
         0.5,  0.0,  0.0,
         0.0, -0.5,  0.0
    ]),
    // 三角形（3顶点）
    triangle: new Float32Array([
         0.0,  0.5,  0.0,
        -0.5, -0.3,  0.0,
         0.5, -0.3,  0.0
    ]),
    // 正方形（4顶点）
    square: new Float32Array([
        -0.4, -0.4, 0.0,
         0.4, -0.4, 0.0,
        -0.4,  0.4, 0.0,
         0.4,  0.4, 0.0
    ]),
    // 五边形（5顶点）
    pentagon: new Float32Array([
         0.0,  0.5,  0.0,
        -0.4,  0.2,  0.0,
        -0.3, -0.4,  0.0,
         0.3, -0.4,  0.0,
         0.4,  0.2,  0.0
    ])
};

// 初始化函数
function init() {
    // 获取画布和WebGL上下文
    canvas = document.getElementById("transform-canvas");
    gl = canvas.getContext("webgl2");
    if (!gl) {
        alert("WebGL 2.0 不可用，请使用支持的浏览器（如Chrome、Firefox）");
        return;
    }

    // 配置WebGL环境
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0); // 白色背景

    // 初始化着色器程序
    program = initShaders(gl, "v-shader", "f-shader");
    if (!program) {
        console.error("着色器程序初始化失败");
        return;
    }
    gl.useProgram(program);

    // 创建顶点缓冲区（复用）
    bufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
    // 加载默认图形（菱形）
    gl.bufferData(gl.ARRAY_BUFFER, shapes.diamond, gl.STATIC_DRAW);

    // 配置顶点属性
    const vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    // 获取变换矩阵的uniform位置
    transformLoc = gl.getUniformLocation(program, "transform");
    if (!transformLoc) {
        console.error("找不到transform变量");
        return;
    }

    // 绑定控件事件
    bindEvents();

    // 开始渲染循环
    render();
}

// 绑定控件事件
function bindEvents() {
    // 图形选择切换
    const shapeSelect = document.getElementById("shapeSelect");
    shapeSelect.addEventListener("change", function(e) {
        currentShape = e.target.value;
        // 更新缓冲区数据为选中图形的顶点
        gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
        gl.bufferData(gl.ARRAY_BUFFER, shapes[currentShape], gl.STATIC_DRAW);
    });

    // 平移控制
    const txInput = document.getElementById("tx");
    const tyInput = document.getElementById("ty");
    txInput.addEventListener("input", function(e) {
        tx = parseFloat(e.target.value);
        document.getElementById("txValue").textContent = tx.toFixed(1);
    });
    tyInput.addEventListener("input", function(e) {
        ty = parseFloat(e.target.value);
        document.getElementById("tyValue").textContent = ty.toFixed(1);
    });

    // 旋转方向反转
    document.getElementById("reverseDir").addEventListener("click", function() {
        direction *= -1;
    });

    // 旋转速度控制
    document.getElementById("speedUp").addEventListener("click", function() {
        delay = Math.max(10, delay / 2); // 最小延迟10ms
    });
    document.getElementById("slowDown").addEventListener("click", function() {
        delay = Math.min(1000, delay * 2); // 最大延迟1000ms
    });

    // 缩放控制
    const scaleInput = document.getElementById("scale");
    scaleInput.addEventListener("input", function(e) {
        scale = parseFloat(e.target.value);
        document.getElementById("scaleValue").textContent = scale.toFixed(1);
    });
}

// 矩阵乘法（4x4矩阵）
function multiplyMatrices(a, b) {
    const result = new Float32Array(16);
    for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
            result[i * 4 + j] = 
                a[i * 4 + 0] * b[0 * 4 + j] +
                a[i * 4 + 1] * b[1 * 4 + j] +
                a[i * 4 + 2] * b[2 * 4 + j] +
                a[i * 4 + 3] * b[3 * 4 + j];
        }
    }
    return result;
}

// 生成旋转矩阵（绕Z轴）
function getRotationMatrix(angle) {
    const c = Math.cos(angle);
    const s = Math.sin(angle);
    return new Float32Array([
        c,  s, 0, 0,
       -s,  c, 0, 0,
        0,  0, 1, 0,
        0,  0, 0, 1
    ]);
}

// 生成平移矩阵
function getTranslationMatrix(tx, ty) {
    return new Float32Array([
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        tx, ty, 0, 1
    ]);
}

// 生成缩放矩阵
function getScaleMatrix(scale) {
    return new Float32Array([
        scale, 0, 0, 0,
        0, scale, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1
    ]);
}

// 计算最终变换矩阵（缩放→旋转→平移）
function getFinalTransformMatrix() {
    const scaleMat = getScaleMatrix(scale);
    const rotateMat = getRotationMatrix(theta);
    const translateMat = getTranslationMatrix(tx, ty);

    // 矩阵组合顺序：先缩放，再旋转，最后平移（图形学标准顺序）
    const scaleRotate = multiplyMatrices(rotateMat, scaleMat);
    return multiplyMatrices(translateMat, scaleRotate);
}

// 渲染函数
function render() {
    // 清空画布
    gl.clear(gl.COLOR_BUFFER_BIT);

    // 更新旋转角度（持续动画）
    theta += direction * 0.05;
    // 保持角度在0~2π范围
    if (theta > 2 * Math.PI) theta -= 2 * Math.PI;
    else if (theta < 0) theta += 2 * Math.PI;

    // 计算并设置最终变换矩阵
    const finalTransform = getFinalTransformMatrix();
    gl.uniformMatrix4fv(transformLoc, false, finalTransform);

    // 根据当前图形获取顶点数量并绘制
    const vertexCount = {
        diamond: 4,
        triangle: 3,
        square: 4,
        pentagon: 5
    }[currentShape];

    gl.drawArrays(gl.TRIANGLE_STRIP, 0, vertexCount);

    // 循环渲染（控制动画帧率）
    setTimeout(() => {
        requestAnimationFrame(render);
    }, delay);
}

// 着色器初始化工具函数
function initShaders(gl, vShaderId, fShaderId) {
    // 创建着色器程序
    const program = gl.createProgram();

    // 编译顶点着色器
    const vShader = compileShader(gl, gl.VERTEX_SHADER, document.getElementById(vShaderId).text);
    // 编译片元着色器
    const fShader = compileShader(gl, gl.FRAGMENT_SHADER, document.getElementById(fShaderId).text);

    // 附加着色器到程序并链接
    gl.attachShader(program, vShader);
    gl.attachShader(program, fShader);
    gl.linkProgram(program);

    // 检查链接错误
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        alert("着色器链接失败: " + gl.getProgramInfoLog(program));
        gl.deleteProgram(program);
        return null;
    }

    return program;
}

// 着色器编译工具函数
function compileShader(gl, type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);

    // 检查编译错误
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        alert("着色器编译失败: " + gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
    }

    return shader;
}

// 页面加载完成后初始化
window.onload = init;